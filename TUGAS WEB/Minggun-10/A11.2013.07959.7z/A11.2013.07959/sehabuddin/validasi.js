alert("welcome bro ......");


function validasi() {
    var Name = document.getElementById("name").value;
    var Email = document.getElementById("email").value;
    var Subject = document.getElementById("subject").value;
    var Message= document.getElementById("message").value;
  
    if (Name != "" && Email!="" && Subject !=""&& Message !="") {
        alert('pesan terkirim');
        return true;
        
    }else{
        alert('Anda harus mengisi data dengan lengkap !');
    }
}